from .funs import prettify_result
from .funs import prettify_results